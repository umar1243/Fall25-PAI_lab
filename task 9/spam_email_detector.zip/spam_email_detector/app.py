from flask import Flask, render_template, request
from model import predict_email

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    email = request.form['email']
    result = predict_email(email)
    return render_template("index.html", prediction=result, email=email)

if __name__ == "__main__":
    app.run(debug=True)
