from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

emails = [
    "Win a free lottery now",
    "Congratulations you won prize",
    "Meeting scheduled tomorrow",
    "Please submit assignment",
    "Claim your free gift",
    "Project deadline is today",
    "You are selected for reward",
    "Let's discuss project work"
]

labels = ["spam", "spam", "ham", "ham", "spam", "ham", "spam", "ham"]

vectorizer = CountVectorizer()
X = vectorizer.fit_transform(emails)

model = MultinomialNB()
model.fit(X, labels)

def predict_email(text):
    return model.predict(vectorizer.transform([text]))[0]
