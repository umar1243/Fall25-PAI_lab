from vector_db import search
from llm import generate_response

def chat(query):
    docs = search(query)
    context = "\n".join(docs)

    prompt = f"""
Context:
{context}

Question:
{query}
"""

    return generate_response(prompt)
