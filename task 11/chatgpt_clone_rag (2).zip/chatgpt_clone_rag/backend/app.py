from flask import Flask, request, Response, stream_with_context
from rag_engine import chat

app = Flask(__name__)

@app.route("/chat", methods=["POST"])
def chat_api():
    data = request.json
    query = data["query"]

    def generate():
        response = chat(query)
        for word in response.split():
            yield word + " "

    return Response(stream_with_context(generate()), mimetype="text/plain")

if __name__ == "__main__":
    app.run(debug=True)
