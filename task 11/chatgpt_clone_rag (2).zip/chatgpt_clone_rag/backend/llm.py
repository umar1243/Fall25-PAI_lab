import requests
import os

API_KEY = os.getenv("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")

def generate_response(prompt):
    url = "https://api.groq.com/openai/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": "llama-3.1-8b-instant",
        "messages": [
            {"role": "system", "content": "Answer only from context."},
            {"role": "user", "content": prompt}
        ]
    }

    res = requests.post(url, json=data, headers=headers)
    return res.json()["choices"][0]["message"]["content"]
