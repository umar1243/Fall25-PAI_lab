import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")

def create_index(chunks):
    embeddings = model.encode(chunks)
    embeddings = np.array(embeddings).astype("float32")

    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)

    faiss.write_index(index, "../data/faiss.index")
    np.save("../data/chunks.npy", chunks)

def search(query, k=3):
    index = faiss.read_index("../data/faiss.index")
    chunks = np.load("../data/chunks.npy", allow_pickle=True)

    q_emb = model.encode([query]).astype("float32")
    _, I = index.search(q_emb, k)

    return [chunks[i] for i in I[0]]
