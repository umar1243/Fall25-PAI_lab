async function send() {
    let input = document.getElementById("input").value;
    let chat = document.getElementById("chat");

    chat.innerHTML += "<div>You: " + input + "</div>";

    const res = await fetch("/chat", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({query: input})
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let result = "";
    let div = document.createElement("div");
    chat.appendChild(div);

    while(true){
        const {value, done} = await reader.read();
        if(done) break;
        result += decoder.decode(value);
        div.innerHTML = "AI: " + result;
    }
}
