from backend.pdf_loader import load_pdf, chunk_text
from backend.vector_db import create_index
import os

DATA_PATH = "data/docs"
all_chunks = []

for file in os.listdir(DATA_PATH):
    if file.endswith(".pdf"):
        text = load_pdf(os.path.join(DATA_PATH, file))
        chunks = chunk_text(text)
        all_chunks.extend(chunks)

create_index(all_chunks)
print("Index created")
