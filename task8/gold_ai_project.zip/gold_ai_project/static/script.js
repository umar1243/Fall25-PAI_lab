let chart;

async function getPrice() {
    const res = await fetch('/gold-price');
    const data = await res.json();

    document.getElementById("price").innerText = data.price;

    loadHistory();
    getPrediction();
}

async function loadHistory() {
    const res = await fetch('/history');
    const data = await res.json();

    if (chart) chart.destroy();

    chart = new Chart(document.getElementById("chart"), {
        type: 'line',
        data: {
            labels: data.map((_, i) => i),
            datasets: [{
                label: 'Gold Price',
                data: data
            }]
        }
    });
}

async function getPrediction() {
    const res = await fetch('/predict');
    const data = await res.json();

    document.getElementById("prediction").innerText = data.prediction;
}

async function setAlert() {
    const price = document.getElementById("alertPrice").value;

    const res = await fetch('/alert', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({price})
    });

    const data = await res.json();
    document.getElementById("alertMsg").innerText = data.message;
}

getPrice();
setInterval(getPrice, 10000);
