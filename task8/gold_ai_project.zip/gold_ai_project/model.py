import pandas as pd
from sklearn.linear_model import LinearRegression

def train_model(data):
    df = pd.DataFrame(data)
    df['day'] = range(len(df))

    X = df[['day']]
    y = df['price']

    model = LinearRegression()
    model.fit(X, y)

    return model

def predict_price(model, next_day):
    return model.predict([[next_day]])[0]
