from flask import Flask, render_template, jsonify, request
import requests
import sqlite3
from model import train_model, predict_price

app = Flask(__name__)

API_KEY = "YOUR_API_KEY"
URL = "https://www.goldapi.io/api/XAU/USD"

headers = {
    "x-access-token": API_KEY
}

def init_db():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS prices (price REAL)")
    conn.commit()
    conn.close()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/gold-price")
def gold_price():
    response = requests.get(URL, headers=headers)
    data = response.json()

    price = data.get("price")

    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("INSERT INTO prices VALUES (?)", (price,))
    conn.commit()
    conn.close()

    return jsonify({"price": price})

@app.route("/history")
def history():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("SELECT price FROM prices")
    data = c.fetchall()
    conn.close()

    prices = [x[0] for x in data]
    return jsonify(prices)

@app.route("/predict")
def predict():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("SELECT price FROM prices")
    data = c.fetchall()
    conn.close()

    prices = [x[0] for x in data]

    if len(prices) < 5:
        return jsonify({"prediction": "Not enough data"})

    model = train_model([{"price": p} for p in prices])
    next_day = len(prices)

    pred = predict_price(model, next_day)

    return jsonify({"prediction": round(pred, 2)})

@app.route("/alert", methods=["POST"])
def alert():
    user_price = float(request.json.get("price"))

    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("SELECT price FROM prices ORDER BY ROWID DESC LIMIT 1")
    current_price = c.fetchone()[0]
    conn.close()

    if current_price >= user_price:
        return jsonify({"message": "Price reached your target!"})
    else:
        return jsonify({"message": "Waiting..."})

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
